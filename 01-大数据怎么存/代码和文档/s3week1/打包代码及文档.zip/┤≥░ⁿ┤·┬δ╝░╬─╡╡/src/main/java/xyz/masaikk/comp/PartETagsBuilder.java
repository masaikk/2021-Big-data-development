package xyz.masaikk.comp;

import com.amazonaws.services.s3.model.PartETag;

import java.util.ArrayList;

public class PartETagsBuilder {
    public static ArrayList<PartETag> getETagsByStringArray(ArrayList<String> stringsETags){
        ArrayList<PartETag> partETags=new ArrayList<PartETag>();
        return partETags;
    }
}
