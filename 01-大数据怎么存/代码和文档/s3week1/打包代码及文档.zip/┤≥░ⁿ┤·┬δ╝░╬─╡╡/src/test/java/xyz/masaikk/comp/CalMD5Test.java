package xyz.masaikk.comp;

import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class CalMD5Test {

    @Test
    public void calculate() {
//        System.out.println(CalMD5.calculate("C:\\Users\\masaikk\\Desktop\\hello.txt"));
/*        List<File> filenames = new ArrayList<>();
        filenames=GetFilesList.getFileList("D:\\librosa-0.6.0");
        for(File file:filenames){
            System.out.println(CalMD5.calculate(file));
        }*/
    }
}