### 程序运行入口
src/main/java/xyz/masaikk/win/Win2.java 的main函数

或者在安装了junit包之后，运行src/test/java/xyz/masaikk/main/MainTest.java中的测试方法

推荐使用IDEA

### 只是想同步文件
可以直接运行src/main/java/xyz/masaikk/main/Main.java
可以跳过选择窗口的GUI而直接进入文件同步的函数
请确保配置文件里面的路径已经存在。